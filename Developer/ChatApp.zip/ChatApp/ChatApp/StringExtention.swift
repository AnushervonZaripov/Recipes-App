//
//  StringExtention.swift
//  ChatApp
//
//  Created by Aziza Azizova on 31/08/23.
//

import Foundation

extension String {
    
    var localized: String {
        NSLocalizedString(self,
                          comment: "\(self) could not be found in Localizable.strings")
    }
}
