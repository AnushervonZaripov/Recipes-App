////
////  ChatViewController.swift
////  ChatApp
////
////  Created by Aziza Azizova on 06/09/23.
////
//
//import UIKit
//import MessageKit
//
//struct Sender: SenderType {
//    var senderId: String
//    var displayName: String
//}
//
//struct Message: MessageType {
//    var sender: MessageKit.SenderType
//    var messageId: String
//    var sentDate: Date
//    var kind: MessageKit.MessageKind
//}
//
//class ChatViewController: MessagesViewController, MessagesDataSource, MessagesLayoutDelegate, MessagesDisplayDelegate {
//    
//    
//
//var currentSender: MessageKit.SenderType
//    
//let currentUser = Sender(senderId: "self", displayName: "iCode")
//    
//let otherUser = Sender(senderId: "other", displayName: "Me")
//    
//var messages = [MessageType]()
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        
//        
//        messages.append(Message(sender: currentUser,
//                                messageId: "1",
//                                sentDate: Date().addingTimeInterval(-86400),
//                                kind: .text("Hello World")))
//        
//        messages.append(Message(sender: otherUser,
//                                messageId: "2",
//                                sentDate: Date().addingTimeInterval(-70000),
//                                kind: .text("How is it going")))
//        
//        messages.append(Message(sender: currentUser,
//                                messageId: "3",
//                                sentDate: Date().addingTimeInterval(-56400),
//                                kind: .text("How is it going")))
//        
//        messages.append(Message(sender: otherUser,
//                                messageId: "4",
//                                sentDate: Date().addingTimeInterval(-36400),
//                                kind: .text("here is a long reply. here is a long reply. here is a long reply.")))
//        
//        
//        messagesCollectionView.messagesDataSource = self
//        messagesCollectionView.messagesLayoutDelegate = self
//        messagesCollectionView.messagesDisplayDelegate = self
//    }
//    
//    func currentSender() -> SenderType {
//        return currentUser
//    }
//    
//    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessageKit.MessagesCollectionView) -> MessageKit.MessageType {
//        return messages[indexPath.section]
//    }
//    
//    func numberOfSections(in messagesCollectionView: MessageKit.MessagesCollectionView) -> Int {
//        return messages.count
//    }
//    
//}
