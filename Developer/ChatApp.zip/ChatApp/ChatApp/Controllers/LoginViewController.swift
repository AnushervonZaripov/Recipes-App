//
//  ViewController.swift
//  ChatApp
//
//  Created by Aziza Azizova on 28/08/23.
//

import UIKit

class LoginViewController: UIViewController {
    
    let scrollView = UIScrollView()
    let logoImageView = UIImageView()
    
    let loginView = UIView()
    let loginField = UITextField()
    let loginIcon = UIImageView()
    
    let passwordView = UIView()
    let passwordField =  UITextField()
    let passwordIcon = UIImageView()

    let continueButton = UIButton()
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
//        title = "Log In"
//        view.backgroundColor = .white
        
//      navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Register",
//                                                            style: .done,
//                                                            target: self,
//                                                            action: #selector(didTapRegister))
        continueButton.addTarget(self,
                              action: #selector(loginButtonTapped),
                              for: .touchUpInside)
        
        //continueButton.addTarget(self, action: #selector(didTapForVc), for: .allTouchEvents)
        loginField.delegate = self
        passwordField.delegate = self
        
        
        //Add subviews
        view.addSubview(scrollView)
        scrollView.addSubview(logoImageView)
        
        scrollView.addSubview(loginView)
        loginView.addSubview(loginIcon)
        loginView.addSubview(loginField)
        
        scrollView.addSubview(passwordView)
        passwordView.addSubview(passwordIcon)
        passwordView.addSubview(passwordField)
        
        scrollView.addSubview(continueButton)
       
        
        setupLogoImage()
        setupEmailView()
        setupEmailField()
        setupEmailIcon()
        setupPasswordView()
        setupPasswordField()
        setupPasswordIcon()
        setupLoginButton()
        
        
        makeConstraint()
        registerKeyboardNotifications()
       
    }
    
    deinit {
        removeKeyboardNotification()
    }
    
   // функция, чтобы на другой экран перейти
    func  didTapForVc() {
             let vc = ChatsCellViewController()
              vc.title = "Chats"
        let nc = UINavigationController(rootViewController: vc)
        nc.modalPresentationStyle = .fullScreen
        navigationController?.pushViewController(vc, animated: true)
        }
    

    func setupLogoImage() {
        logoImageView.image = UIImage(named: "Logo")
        //logoImageView.contentMode = .scaleAspectFit
    }
        
    func setupEmailView() {
        loginView.layer.cornerRadius = 12
        loginView.layer.borderWidth = 1
        loginView.layer.borderColor = UIColor.lightGray.cgColor
        }
    
    func setupEmailField() {
        loginField.autocapitalizationType = .none
        loginField.returnKeyType = .continue
        loginField.placeholder = "login".localized
        loginField.leftViewMode = .always
        loginField.font = UIFont(name: "Poppins", size: 18)
    }
    
    func setupEmailIcon() {
        loginIcon.image = UIImage(named: "LoginIcon")
        loginIcon.contentMode = .bottomLeft
    }
    
    func setupPasswordView() {
        passwordView.layer.cornerRadius = 12
        passwordView.layer.borderWidth = 1
        passwordView.layer.borderColor = UIColor.lightGray.cgColor
        }
    func setupPasswordField() {
        passwordField.autocapitalizationType = .none
        passwordField.autocorrectionType = .no
        passwordField.returnKeyType = .done
        passwordField.layer.borderColor = UIColor.lightGray.cgColor
        passwordField.placeholder = "password".localized
        passwordField.leftViewMode = .always
        passwordField.backgroundColor = .white
        passwordField.font = UIFont(name: "Poppins", size: 18)
        passwordField.isSecureTextEntry = true
    }
    
    func setupPasswordIcon() {
        passwordIcon.image = UIImage(named: "PasswordIcon")
        passwordIcon.contentMode = .bottomLeft
    }
    
    func setupLoginButton() {
        continueButton.setTitle("continue".localized, for: .normal)
        continueButton.backgroundColor = UIColor(named: "ButtonColor")
        continueButton.setTitleColor(.white, for: .normal)
        continueButton.setTitleColor(UIColor(named: "TextColor"), for: .highlighted)
        continueButton.layer.cornerRadius = 12
        continueButton.layer.masksToBounds = true
        continueButton.titleLabel?.font = UIFont(name: "Poppins", size: 18)
    }
    

    @objc private func loginButtonTapped() {
        
        loginField.resignFirstResponder()
        passwordField.resignFirstResponder()
      
        
        guard let name = loginField.text, let password = passwordField.text,
              !name.isEmpty, !password.isEmpty, password.count >= 8, name.count >= 8 else {
                alertUserLoginError()
                return
        }
        didTapForVc()
       
    }
    
    func alertUserLoginError() {
        let alert = UIAlertController(title: "Woops",
                                      message: "Please enter all information to log in.",
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title:"Dismiss",
                                      style: .cancel, handler: nil))
        present(alert, animated: true)
    }

    
    func makeConstraint() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        logoImageView.translatesAutoresizingMaskIntoConstraints = false
        loginIcon.translatesAutoresizingMaskIntoConstraints = false
        loginView.translatesAutoresizingMaskIntoConstraints = false
        loginField.translatesAutoresizingMaskIntoConstraints = false
        passwordField.translatesAutoresizingMaskIntoConstraints = false
        passwordIcon.translatesAutoresizingMaskIntoConstraints = false
        passwordView.translatesAutoresizingMaskIntoConstraints = false
        continueButton.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrollView.rightAnchor.constraint(equalTo: view.rightAnchor),
            scrollView.leftAnchor.constraint(equalTo: view.leftAnchor),

            logoImageView.topAnchor.constraint(equalTo: scrollView.safeAreaLayoutGuide.topAnchor, constant: 78),
            logoImageView.centerXAnchor.constraint(equalTo: scrollView.centerXAnchor),
            logoImageView.widthAnchor.constraint(equalToConstant: 300),
            logoImageView.heightAnchor.constraint(equalToConstant: 320),
            //logoImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
          //  logoImageView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 10),
            //logoImageView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -10),
            
            loginView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loginView.widthAnchor.constraint(equalToConstant: 320),
            loginView.heightAnchor.constraint(equalToConstant: 52),
            loginView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 465),
            
            loginIcon.widthAnchor.constraint(equalToConstant: 32),
            loginIcon.heightAnchor.constraint(equalToConstant: 32),
            loginIcon.centerYAnchor.constraint(equalTo: loginView.centerYAnchor),
            loginIcon.leftAnchor.constraint(equalTo: loginView.leftAnchor, constant: 12),
                        
            loginField.leftAnchor.constraint(equalTo: loginIcon.rightAnchor, constant: 12),
            loginField.heightAnchor.constraint(equalToConstant: 30),
            loginField.centerYAnchor.constraint(equalTo: loginView.centerYAnchor),
            loginField.widthAnchor.constraint(equalToConstant: 270),

            passwordView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            passwordView.widthAnchor.constraint(equalToConstant: 320),
            passwordView.heightAnchor.constraint(equalToConstant: 52),
            passwordView.topAnchor.constraint(equalTo: loginView.bottomAnchor, constant: 20),
            
            passwordIcon.widthAnchor.constraint(equalToConstant: 32),
            passwordIcon.heightAnchor.constraint(equalToConstant: 32),
            passwordIcon.centerYAnchor.constraint(equalTo: passwordView.centerYAnchor),
            passwordIcon.leftAnchor.constraint(equalTo: passwordView.leftAnchor, constant: 12),
                        
            passwordField.leftAnchor.constraint(equalTo: passwordIcon.rightAnchor, constant: 12),
            passwordField.heightAnchor.constraint(equalToConstant: 30),
            passwordField.centerYAnchor.constraint(equalTo: passwordView.centerYAnchor),
            passwordField.widthAnchor.constraint(equalToConstant: 270),
            
            continueButton.topAnchor.constraint(equalTo: passwordView.bottomAnchor, constant: 20),
            continueButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            continueButton.widthAnchor.constraint(equalToConstant: 320),
            continueButton.heightAnchor.constraint(equalToConstant: 52),
            
            
        ])
    }
    
}


extension LoginViewController: UITextFieldDelegate {
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        
        if textField == loginField {
            passwordField.becomeFirstResponder()
        }
        else if textField == passwordField {
            loginButtonTapped()
        }
        
        return true
    }
}

extension LoginViewController {
    func registerKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector:#selector(keyboardWillShow),name: UIResponder.keyboardWillShowNotification,
                                         object: nil)
        
        NotificationCenter.default.addObserver(self, selector:#selector(keyboardWillHide),name: UIResponder.keyboardWillHideNotification,
                                         object: nil)
    }
    
    private func removeKeyboardNotification() {
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    
    @objc private func keyboardWillShow(notification: Notification) {
        let userInfo = notification.userInfo
        let keyboardHeight = (userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        scrollView.contentOffset = CGPoint(x: 0, y: keyboardHeight.height / 2)
    }
    
    @objc private func keyboardWillHide(notification: Notification) {
        scrollView.contentOffset = CGPoint.zero
    }
}

